/*

Fonts class replacements for Cufon

*/

Cufon.replace('.homeportfoliotitle' , { hover: 'true' });
Cufon.replace('.mportfoliotitle' , { hover: 'true' });
Cufon.replace('.abouttext');
Cufon.replace('.footertitle');
Cufon.replace('.abouthighlight');
Cufon.replace('.mblogtitle' , { hover: 'true' });
Cufon.replace('.articletitle' , { hover: 'true' });
Cufon.replace('#title');
Cufon.replace('#titleHighlight');
Cufon.replace('.sidebartitle');
Cufon.replace('#categorytitle');
Cufon.replace('#fullwidth-categorytitle');
Cufon.replace('.subcategorytitle');
Cufon.replace('.recent-highlight');
Cufon.replace('.portfoliotitle',{ hover: 'true' });
Cufon.replace('.recent-title',{ hover: 'true' });
Cufon.replace('#subtitle');
Cufon.replace('.addresstitle');
Cufon.replace('.fulladdress ul li');
Cufon.replace('#contents h1');
Cufon.replace('#contents h2');
Cufon.replace('#contents h3');
Cufon.replace('#contents h4');
Cufon.replace('#contents h5');
Cufon.replace('#contents h6');